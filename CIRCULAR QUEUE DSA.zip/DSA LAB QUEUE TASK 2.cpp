#include <iostream>
using namespace std;

class CircularQueueArray {
    int *queue;
    int size, front, rear, count;
public:
    CircularQueueArray(int s) {
        size = s;
        queue = new int[size];
        front = rear = count = 0;
    }

    bool isEmpty() {
        return count == 0;
    }

    bool isFull() {
        return count == size;
    }

    void enqueue(int value) {
        if (isFull()) return;
        queue[rear] = value;
        rear = (rear + 1) % size;
        count++;
    }

    int dequeue() {
        if (isEmpty()) return -1;
        int val = queue[front];
        front = (front + 1) % size;
        count--;
        return val;
    }

    void display() {
        if (isEmpty()) return;
        for (int i = 0; i < count; i++)
            cout << queue[(front + i) % size] << " ";
        cout << endl;
    }
};

int main() {
    CircularQueueArray q(5);
    q.enqueue(14);
    q.enqueue(22);
    q.enqueue(13);
    q.enqueue(-6);
    q.display();
    cout << "Deleted value = " << q.dequeue() << endl;
    cout << "Deleted value = " << q.dequeue() << endl;
    q.display();
    q.enqueue(9);
    q.enqueue(20);
    q.enqueue(5);
    q.display();
    q.enqueue(20);
    return 0;
}
