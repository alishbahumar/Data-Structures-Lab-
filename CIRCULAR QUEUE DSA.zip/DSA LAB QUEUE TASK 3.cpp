#include <iostream>
using namespace std;

class CircularQueue {
    int *queue;
    int size, front, rear;
public:
    CircularQueue(int s) {
        size = s;
        queue = new int[size];
        front = rear = -1;
    }

    void enQueue(int data) {
        if ((front == 0 && rear == size - 1) || (rear + 1) % size == front)
            return;
        if (front == -1) {
            front = rear = 0;
            queue[rear] = data;
        } else {
            rear = (rear + 1) % size;
            queue[rear] = data;
        }
    }

    int deQueue() {
        if (front == -1) return -1;
        int temp = queue[front];
        if (front == rear)
            front = rear = -1;
        else
            front = (front + 1) % size;
        return temp;
    }

    void displayQueue() {
        if (front == -1) return;
        int i = front;
        while (true) {
            cout << queue[i] << " ";
            if (i == rear) break;
            i = (i + 1) % size;
        }
        cout << endl;
    }
};

int main() {
    CircularQueue q(5);
    q.enQueue(14);
    q.enQueue(22);
    q.enQueue(13);
    q.enQueue(-6);
    q.displayQueue();
    cout << "Deleted value = " << q.deQueue() << endl;
    cout << "Deleted value = " << q.deQueue() << endl;
    q.displayQueue();
    q.enQueue(9);
    q.enQueue(20);
    q.enQueue(5);
    q.displayQueue();
    q.enQueue(20);
    return 0;
}