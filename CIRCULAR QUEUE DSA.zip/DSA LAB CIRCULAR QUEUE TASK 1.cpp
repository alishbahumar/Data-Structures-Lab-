#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* link;
};

class CircularQueueLinkedList {
    Node *front, *rear;
public:
    CircularQueueLinkedList() {
        front = rear = nullptr;
    }

    void enQueue(int value) {
        Node* temp = new Node();
        temp->data = value;
        if (!front)
            front = temp;
        else
            rear->link = temp;
        rear = temp;
        rear->link = front;
    }

    int deQueue() {
        if (!front)
            return -1;
        int value;
        if (front == rear) {
            value = front->data;
            front = rear = nullptr;
        } else {
            Node* temp = front;
            value = temp->data;
            front = front->link;
            rear->link = front;
            delete temp;
        }
        return value;
    }

    void displayQueue() {
        if (!front) return;
        Node* temp = front;
        do {
            cout << temp->data << " ";
            temp = temp->link;
        } while (temp != front);
        cout << endl;
    }
};

int main() {
    CircularQueueLinkedList q;
    q.enQueue(14);
    q.enQueue(22);
    q.enQueue(6);
    q.displayQueue();
    cout << "Deleted value = " << q.deQueue() << endl;
    cout << "Deleted value = " << q.deQueue() << endl;
    q.displayQueue();
    q.enQueue(9);
    q.enQueue(20);
    q.displayQueue();
    return 0;
}