#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void createList(int n) {
    Node* newNode, *temp;
    int data;
    for (int i = 0; i < n; i++) {
        cout << "Enter mark " << i + 1 << ": ";
        cin >> data;

        newNode = new Node;
        newNode->data = data;
        newNode->prev = NULL;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
        } else {
            temp = head;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->prev = temp;
        }
    }
}

void display() {
    Node* temp = head;
    cout << "List: ";
    while (temp != NULL) {
        cout << temp->data << " <-> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

int main() {
    int n;
    cout << "Enter number of marks: ";
    cin >> n;
    createList(n);
    display();
    return 0;
}
