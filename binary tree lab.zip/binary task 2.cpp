#include <iostream>
#include <string>
using namespace std;

class Employee {
public:
    int id;
    string name;
    double salary;

    Employee(int id = 0, string name = "", double salary = 0.0) {
        this->id = id;
        this->name = name;
        this->salary = salary;
    }
};

struct Node {
    Employee data;
    Node* left;
    Node* right;

    Node(Employee emp) {
        data = emp;
        left = right = nullptr;
    }
};
class EmployeeBST {
private:
    Node* root;

    Node* insert(Node* node, Employee emp) {
        if (node == nullptr)
            return new Node(emp);

        if (emp.id < node->data.id)
            node->left = insert(node->left, emp);
        else if (emp.id > node->data.id)
            node->right = insert(node->right, emp);

        return node;
    }

    Node* search(Node* node, int id) {
        if (node == nullptr || node->data.id == id)
            return node;

        if (id < node->data.id)
            return search(node->left, id);

        return search(node->right, id);
    }

    Node* findMin(Node* node) {
        while (node && node->left)
            node = node->left;
        return node;
    }

    Node* deleteNode(Node* node, int id) {
        if (node == nullptr)
            return node;

        if (id < node->data.id)
            node->left = deleteNode(node->left, id);
        else if (id > node->data.id)
            node->right = deleteNode(node->right, id);
        else {
 
            if (node->left == nullptr && node->right == nullptr) {
                delete node;
                return nullptr;
            }         
            else if (node->left == nullptr) {
                Node* temp = node->right;
                delete node;
                return temp;
            }
            else if (node->right == nullptr) {
                Node* temp = node->left;
                delete node;
                return temp;
            }
         
            Node* temp = findMin(node->right);
            node->data = temp->data;
            node->right = deleteNode(node->right, temp->data.id);
        }
        return node;
    }
    void inorder(Node* node) {
        if (!node) return;
        inorder(node->left);
        cout << node->data.id << " | " << node->data.name << " | " << node->data.salary << endl;
        inorder(node->right);
    }
void preorder(Node* node) {
        if (!node) return;
        cout << node->data.id << " | " << node->data.name << " | " << node->data.salary << endl;
        preorder(node->left);
        preorder(node->right);
    }
void postorder(Node* node) {
        if (!node) return;
        postorder(node->left);
        postorder(node->right);
        cout << node->data.id << " | " << node->data.name << " | " << node->data.salary << endl;
    }
public:
    EmployeeBST() {
        root = nullptr;
    }
void insert(Employee emp) {
        root = insert(root, emp);
    }
void search(int id) {
        Node* result = search(root, id);
        if (result) {
            cout << "Employee Found: " 
                 << result->data.id << " | " 
                 << result->data.name << " | " 
                 << result->data.salary << endl;
        } else {
            cout << "Employee NOT found." << endl;
        }
    }
void deleteEmployee(int id) {
        root = deleteNode(root, id);
    }
 void displayInOrder() {
        cout << "\nIn-order Traversal:\n";
        inorder(root);
    }
 void displayPreOrder() {
        cout << "\nPre-order Traversal:\n";
        preorder(root);
    }
void displayPostOrder() {
        cout << "\nPost-order Traversal:\n";
        postorder(root);
    }
};
int main() {
    EmployeeBST bst;

    bst.insert(Employee(1, "Alina", 55000));
    bst.insert(Employee(2, "Ayesha", 48000));
    bst.insert(Employee(3, "nayyab", 82000));
    bst.insert(Employee(4, "Aima", 46000));
  

    bst.search(1);
    bst.search(4);

    bst.deleteEmployee(3);

    bst.displayInOrder();
    bst.displayPreOrder();
    bst.displayPostOrder();

    return 0;
}
