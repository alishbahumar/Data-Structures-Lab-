#include <iostream>
using namespace std;

int main() {
    int n;

    cout << "Enter number of people in class: ";
    cin >> n;

 
    int knows[50][50];  

   
    cout << "\nEnter 1 if person i knows person j, otherwise 0:\n\n";

    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {

            if(i == j) {
                knows[i][j] = 0;  
                continue;
            }

            cout << "Does person " << i << " know person " << j << "? (1/0): ";
            cin >> knows[i][j];
        }
    }

    
    cout << "\nAdjacency Matrix (Directed Graph):\n";
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            cout << knows[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
