#include <iostream>
using namespace std;

int main() {
    const int n = 5; 
    int simple[n][n] = {0};      
    int multigraph[n][n] = {0};  
    int loopGraph[n][n] = {0};   


    simple[0][1] = simple[1][0] = 1; 
    simple[1][2] = simple[2][1] = 1; 
    simple[1][3] = simple[3][1] = 1; 
    simple[1][4] = simple[4][1] = 1; 
    simple[4][2] = simple[2][4] = 1; 


    multigraph[0][1] = multigraph[1][0] = 6; 
    multigraph[1][2] = multigraph[2][1] = 5; 
    multigraph[1][3] = multigraph[3][1] = 3; 
    multigraph[1][4] = multigraph[4][1] = 5; 
    multigraph[4][2] = multigraph[2][4] = 1; 

    
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            loopGraph[i][j] = multigraph[i][j];
    loopGraph[2][2] = 1; // loop at Miami

    
    cout << "Simple Graph (1):\n";
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++)
            cout << simple[i][j] << " ";
        cout << endl;
    }

    cout << "\nMultigraph (2):\n";
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++)
            cout << multigraph[i][j] << " ";
        cout << endl;
    }

    cout << "\nLoop Graph (3):\n";
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++)
            cout << loopGraph[i][j] << " ";
        cout << endl;
    }

    return 0;
}
