#include <iostream>
using namespace std;

  

int adj[MAX][MAX];   
int visited[MAX];


int q[50], front = 0, rear = 0;

void enqueue(int x) {
    q[rear++] = x;
}

int dequeue() {
    return q[front++];
}


void DFS(int node) {
    visited[node] = 1;
    cout << (char)(node + 'A') << " ";

    for (int i = 0; i < MAX; i++) {
        if (adj[node][i] == 1 && visited[i] == 0) {
            DFS(i);
        }
    }
}


void BFS(int start) {
    for (int i = 0; i < MAX; i++)
        visited[i] = 0;

    enqueue(start);
    visited[start] = 1;

    while (front != rear) {
        int node = dequeue();
        cout << (char)(node + 'A') << " ";

        for (int i = 0; i < MAX; i++) {
            if (adj[node][i] == 1 && visited[i] == 0) {
                enqueue(i);
                visited[i] = 1;
            }
        }
    }
}

int main() {

   
    for (int i = 0; i < MAX; i++)
        for (int j = 0; j < MAX; j++)
            adj[i][j] = 0;

    adj[0][1] = adj[1][0] = 1; 
    adj[1][2] = adj[2][1] = 1; 
    adj[1][3] = adj[3][1] = 1; 
    adj[2][4] = adj[4][2] = 1; 
    adj[3][4] = adj[4][3] = 1; 
    adj[4][5] = adj[5][4] = 1; 

   
    cout << "Adjacency Matrix:\n";
    for (int i = 0; i < MAX; i++) {
        for (int j = 0; j < MAX; j++) {
            cout << adj[i][j] << " ";
        }
        cout << endl;
    }

    
    cout << "\nAdjacency List:\n";
    for (int i = 0; i < MAX; i++) {
        cout << (char)(i + 'A') << " -> ";
        for (int j = 0; j < MAX; j++) {
            if (adj[i][j] == 1)
                cout << (char)(j + 'A') << " ";
        }
        cout << endl;
    }

    
    for (int i = 0; i < MAX; i++) visited[i] = 0;

    cout << "\nDFS starting from A:\n";
    DFS(0);

    
    cout << "\n\nBFS starting from A:\n";
    front = rear = 0;
    BFS(0);

    return 0;
}
