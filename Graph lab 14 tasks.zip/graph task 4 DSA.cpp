#include <iostream>
using namespace std;

#define N 9  

int adj[N][N];
int visited[N];
int q[50], frontt = 0, rearp = 0;

void enqueue(int x){
    q[rearp++] = x;
}
int dequeue(){
    return q[frontt++];
}

void DFS(int node){
    visited[node] = 1;
    cout << node << " ";

    for(int i=0; i<N; i++){
        if(adj[node][i] == 1 && visited[i] == 0){
            DFS(i);
        }
    }
}

void BFS(int start){
    for(int i=0; i<N; i++) visited[i] = 0;

    enqueue(start);
    visited[start] = 1;

    while(frontt != rearp){
        int node = dequeue();
        cout << node << " ";

        for(int i=0; i<N; i++){
            if(adj[node][i] == 1 && visited[i] == 0){
                enqueue(i);
                visited[i] = 1;
            }
        }
    }
}

int main(){
    
    for(int i=0; i<N; i++)
        for(int j=0; j<N; j++)
            adj[i][j] = 0;

    
    adj[0][1] = adj[1][0] = 1;
    adj[0][3] = adj[3][0] = 1;
    adj[0][8] = adj[8][0] = 1;
    adj[1][7] = adj[7][1] = 1;
    adj[2][3] = adj[3][2] = 1;
    adj[2][5] = adj[5][2] = 1;
    adj[2][7] = adj[7][2] = 1;
    adj[3][4] = adj[4][3] = 1;
    adj[5][6] = adj[6][5] = 1;

    cout << "DFS starting at 0:\n";
    for(int i=0; i<N; i++) visited[i]=0;
    DFS(0);

    cout << "\n\nBFS starting at 0:\n";
    frontt = rearp = 0;
    BFS(0);

    return 0;
}
