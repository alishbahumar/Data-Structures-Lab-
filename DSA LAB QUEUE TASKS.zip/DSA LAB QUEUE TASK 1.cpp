#include <iostream>
#include <string>
using namespace std;

class Applicant {
public:
    int applicant_id;
    float height;
    float weight;
    float eyesight;
    string status;

    Applicant() {
        applicant_id = 0;
        height = 0;
        weight = 0;
        eyesight = 0;
        status = "Waiting";
    }

    Applicant(int id, float h, float w, float e, string s = "Waiting") {
        applicant_id = id;
        height = h;
        weight = w;
        eyesight = e;
        status = s;
    }

    void display() {
        cout << "\nID: " << applicant_id
             << "\nHeight: " << height
             << "\nWeight: " << weight
             << "\nEyesight: " << eyesight
             << "\nStatus: " << status << endl;
    }
};

class Queue {
private:
    struct Node {
        Applicant data;
        Node* next;
        Node* prev;
    };
    Node* front;
    Node* rear;

public:
    Queue() {
        front = nullptr;
        rear = nullptr;
    }

    bool isEmpty() {
        return front == nullptr;
    }

    void enqueue(Applicant a) {
        Node* newNode = new Node;
        newNode->data = a;
        newNode->next = nullptr;
        newNode->prev = rear;

        if (isEmpty()) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
        cout << "Applicant " << a.applicant_id << " added to the line.\n";
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "No applicant in the line.\n";
            return;
        }
        Node* temp = front;
        cout << "\nApplicant " << temp->data.applicant_id << " has given the test and left the line.\n";
        front = front->next;
        if (front)
            front->prev = nullptr;
        else
            rear = nullptr;
        delete temp;
    }

    void removeSecondApplicant() {
        if (front == nullptr || front->next == nullptr) {
            cout << "\nNot enough applicants to remove the 2nd one.\n";
            return;
        }

        Node* second = front->next;
        Node* third = second->next;

        cout << "\nApplicant " << second->data.applicant_id << " (2nd position) had urgency and left the line.\n";

        front->next = third;
        if (third != nullptr)
            third->prev = front;
        else
            rear = front;

        delete second;
    }

    void displayQueue() {
        if (isEmpty()) {
            cout << "\nNo applicants in the line.\n";
            return;
        }

        cout << "\nCurrent Applicants in Line:\n";
        Node* current = front;
        int position = 1;
        while (current != nullptr) {
            cout << "\nPosition " << position++ << ":";
            current->data.display();
            cout << "----------------------";
            current = current->next;
        }
    }
};

int main() {
    Queue q;

    q.enqueue(Applicant(101, 5.8, 68, 6.0));
    q.enqueue(Applicant(102, 5.7, 70, 5.9));
    q.enqueue(Applicant(103, 6.0, 72, 6.1));
    q.enqueue(Applicant(104, 5.9, 65, 6.0));
    q.enqueue(Applicant(105, 6.1, 75, 6.2));
    q.enqueue(Applicant(106, 5.6, 60, 5.8));
    q.enqueue(Applicant(107, 5.7, 62, 5.9));

    q.displayQueue();

    q.removeSecondApplicant();
    q.displayQueue();

    q.dequeue();
    q.displayQueue();

    return 0;
}