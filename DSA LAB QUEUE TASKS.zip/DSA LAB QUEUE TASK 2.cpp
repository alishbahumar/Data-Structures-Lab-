#include <iostream>
#include <string>
using namespace std;

class Queue {
private:
    struct Node {
        int truck_id;
        Node* next;
    };
    Node* front;
    Node* rear;
public:
    Queue() {
        front = rear = nullptr;
    }

    bool isEmpty() {
        return front == nullptr;
    }

    void enqueue(int id) {
        Node* newNode = new Node;
        newNode->truck_id = id;
        newNode->next = nullptr;
        if (isEmpty()) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
        cout << "Truck " << id << " is now on the road.\n";
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "No trucks on the road.\n";
            return;
        }
        Node* temp = front;
        cout << "Truck " << temp->truck_id << " has left the road.\n";
        front = front->next;
        if (!front) rear = nullptr;
        delete temp;
    }

    bool removeTruck(int id) {
        if (isEmpty()) return false;
        Node* current = front;
        Node* prev = nullptr;
        while (current != nullptr) {
            if (current->truck_id == id) {
                if (prev == nullptr) front = current->next;
                else prev->next = current->next;
                if (current == rear) rear = prev;
                delete current;
                return true;
            }
            prev = current;
            current = current->next;
        }
        return false;
    }

    void display() {
        if (isEmpty()) {
            cout << "No trucks on the road.\n";
            return;
        }
        cout << "\nTrucks currently on the road:\n";
        Node* temp = front;
        while (temp != nullptr) {
            cout << "Truck " << temp->truck_id << endl;
            temp = temp->next;
        }
    }
};

class Stack {
private:
    struct Node {
        int truck_id;
        Node* next;
    };
    Node* top;
public:
    Stack() {
        top = nullptr;
    }

    bool isEmpty() {
        return top == nullptr;
    }

    void push(int id) {
        Node* newNode = new Node;
        newNode->truck_id = id;
        newNode->next = top;
        top = newNode;
        cout << "Truck " << id << " has entered the garage.\n";
    }

    void pop() {
        if (isEmpty()) {
            cout << "No trucks in the garage.\n";
            return;
        }
        Node* temp = top;
        cout << "Truck " << temp->truck_id << " has exited the garage.\n";
        top = top->next;
        delete temp;
    }

    void exitGarage(int id) {
        if (isEmpty()) {
            cout << "Garage is empty.\n";
            return;
        }
        if (top->truck_id == id) {
            pop();
        } else {
            cout << "Error: Truck " << id << " is not near the garage door.\n";
        }
    }

    void display() {
        if (isEmpty()) {
            cout << "No trucks in the garage.\n";
            return;
        }
        cout << "\nTrucks currently in the garage (top to bottom):\n";
        Node* temp = top;
        while (temp != nullptr) {
            cout << "Truck " << temp->truck_id << endl;
            temp = temp->next;
        }
    }
};

int main() {
    Queue road;
    Stack garage;
    int choice, id;
    cout << "===== GARAGE AND ROAD TRUCK MANAGEMENT SYSTEM =====\n";

    do {
        cout << "\n1. On_road(truck_id)";
        cout << "\n2. Enter_garage(truck_id)";
        cout << "\n3. Exit_garage(truck_id)";
        cout << "\n4. Show_trucks(garage)";
        cout << "\n5. Show_trucks(road)";
        cout << "\n6. Exit Program";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter truck ID: ";
            cin >> id;
            road.enqueue(id);
            break;
        case 2:
            cout << "Enter truck ID to move from road to garage: ";
            cin >> id;
            if (road.removeTruck(id))
                garage.push(id);
            else
                cout << "Truck " << id << " not found on road.\n";
            break;
        case 3:
            cout << "Enter truck ID to exit from garage: ";
            cin >> id;
            garage.exitGarage(id);
            break;
        case 4:
            garage.display();
            break;
        case 5:
            road.display();
            break;
        case 6:
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid choice!\n";
        }
    } while (choice != 6);

    return 0;
}