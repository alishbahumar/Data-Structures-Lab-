#include <iostream>
using namespace std;
 
int binarySearch(int arr[], int left, int right, int key) {
    if (left > right)
        return -1;  

    int mid = (left + right) / 2;

    if (arr[mid] == key)
        return mid;
    else if (key < arr[mid])
        return binarySearch(arr, left, mid - 1, key);
    else
        return binarySearch(arr, mid + 1, right, key);
}

int linearSearch(int arr[], int size, int index, int key) {
    if (index == size)
        return -1;  

    if (arr[index] == key)
        return index;

    return linearSearch(arr, size, index + 1, key);
}

int factorial(int n) {
    if (n == 0 || n == 1)
        return 1;

    return n * factorial(n - 1);
}

int sumArray(int arr[], int size) {
    if (size == 0)
        return 0;

    return arr[size - 1] + sumArray(arr, size - 1);
}

int main() {
    int luckyNumbers[10] = {13579, 26791, 26792, 33445, 55555,
                            62483, 77777, 79422, 85647, 93121};

    int winner;
    cout << "Enter this week's winning 5-digit number: ";
    cin >> winner;
 
    bool found = false;

    for (int i = 0; i < 10; i++) {
        if (luckyNumbers[i] == winner) {
            found = true;
            break;
        }
    }

    if (found)
        cout << "Congratulations! You have the winning ticket!" << endl;
    else
        cout << "Sorry, your tickets did not win this week." << endl;

    cout << "\n--- Recursive Function ---\n";

    int key = 55555;
    int index = linearSearch(luckyNumbers, 10, 0, key);
    cout << "Recursive Linear Search for " << key << ": ";
    if (index != -1)
        cout << "Found at index " << index << endl;
    else
        cout << "Not found\n";

    int indexB = binarySearch(luckyNumbers, 0, 9, key);
    cout << "Recursive Binary Search for " << key << ": ";
    if (indexB != -1)
        cout << "Found at index " << indexB << endl;
    else
        cout << "Not found\n";

    int n = 5;
    cout << "Factorial of " << n << " = " << factorial(n) << endl;

    cout << "Sum of all lucky numbers = " << sumArray(luckyNumbers, 10) << endl;

    return 0;
}
