#include <iostream>
#include <string>
using namespace std;

class Book {
private:
    string title;
    float price;
    int edition;
    int pages;
public:
    Book() {
        title = "";
        price = 0;
        edition = 0;
        pages = 0;
    }
    Book(string t, float p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
    }
    void display() {
        cout << "\nTitle: " << title;
        cout << "\nPrice: " << price;
        cout << "\nEdition: " << edition;
        cout << "\nPages: " << pages << endl;
    }
};

class Stack {
private:
    struct Node {
        Book data;
        Node* next;
    };
    Node* top;
public:
    Stack() {
        top = nullptr;
    }
    bool isEmpty() {
        return top == nullptr;
    }
    void push(Book b) {
        Node* newNode = new Node;
        newNode->data = b;
        newNode->next = top;
        top = newNode;
        cout << "\nBook pushed successfully.";
    }
    void pop() {
        if (isEmpty()) {
            cout << "\nStack is empty, nothing to pop.";
            return;
        }
        Node* temp = top;
        cout << "\nPopping book:";
        temp->data.display();
        top = top->next;
        delete temp;
    }
    void peek() {
        if (isEmpty()) {
            cout << "\nStack is empty.";
            return;
        }
        cout << "\nTop book in the stack:";
        top->data.display();
    }
    void displayAll() {
        if (isEmpty()) {
            cout << "\nNo books in the stack.";
            return;
        }
        cout << "\nBooks currently in stack:\n";
        Node* current = top;
        while (current != nullptr) {
            current->data.display();
            cout << "----------------------";
            current = current->next;
        }
    }
};

int main() {
    Stack bookStack;
    Book b1("C++ Programming", 750, 3, 520);
    Book b2("Data Structures", 650, 2, 480);
    Book b3("Operating Systems", 850, 4, 600);
    Book b4("Database Systems", 700, 3, 560);
    Book b5("Computer Networks", 800, 5, 590);

    bookStack.push(b1);
    bookStack.push(b2);
    bookStack.push(b3);
    bookStack.push(b4);
    bookStack.push(b5);

    bookStack.peek();

    bookStack.pop();
    bookStack.pop();

    bookStack.displayAll();

    return 0;
}