#include <iostream>
using namespace std;

class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;
public:
    Inventory() {
        serialNum = 0;
        manufactYear = 0;
        lotNum = 0;
    }
    Inventory(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }
    void setSerialNum(int s) { serialNum = s; }
    void setManufactYear(int y) { manufactYear = y; }
    void setLotNum(int l) { lotNum = l; }
    int getSerialNum() { return serialNum; }
    int getManufactYear() { return manufactYear; }
    int getLotNum() { return lotNum; }
    void display() {
        cout << "\nSerial Number: " << serialNum;
        cout << "\nManufacture Year: " << manufactYear;
        cout << "\nLot Number: " << lotNum << endl;
    }
};

class Stack {
private:
    struct Node {
        Inventory data;
        Node* next;
    };
    Node* top;
public:
    Stack() {
        top = nullptr;
    }
    ~Stack() {
        while (!isEmpty()) {
            pop();
        }
    }
    bool isEmpty() {
        return (top == nullptr);
    }
    void push(Inventory item) {
        Node* newNode = new Node;
        newNode->data = item;
        newNode->next = top;
        top = newNode;
        cout << "Part added to inventory successfully!\n";
    }
    void pop() {
        if (isEmpty()) {
            cout << "Inventory is empty! Nothing to remove.\n";
            return;
        }
        Node* temp = top;
        cout << "\nRemoving the top part from inventory:\n";
        temp->data.display();
        top = top->next;
        delete temp;
    }
    void displayAll() {
        if (isEmpty()) {
            cout << "\nNo parts left in inventory.\n";
            return;
        }
        cout << "\nRemaining parts in inventory:\n";
        Node* current = top;
        while (current != nullptr) {
            current->data.display();
            cout << "-----------------------";
            current = current->next;
        }
    }
};

int main() {
    Stack inventoryStack;
    int choice;
    cout << "===== INVENTORY MANAGEMENT USING STACK (LINKED LIST) =====\n";
    do {
        cout << "\n1. Add a part to inventory (Push)";
        cout << "\n2. Remove a part from inventory (Pop)";
        cout << "\n3. Exit and show remaining inventory";
        cout << "\nEnter your choice: ";
        cin >> choice;
        if (choice == 1) {
            int serial, year, lot;
            cout << "\nEnter Serial Number: ";
            cin >> serial;
            cout << "Enter Manufacture Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;
            Inventory part(serial, year, lot);
            inventoryStack.push(part);
        }
        else if (choice == 2) {
            inventoryStack.pop();
        }
        else if (choice == 3) {
            cout << "\nExiting program...\n";
            inventoryStack.displayAll();
        }
        else {
            cout << "Invalid choice! Please try again.\n";
        }
    } while (choice != 3);
    cout << "\nProgram ended successfully.\n";
    return 0;
}